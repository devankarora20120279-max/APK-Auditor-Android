package com.apkauditor.mobile;

import android.app.Activity;
import android.os.Bundle;
import android.webkit.WebChromeClient;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.webkit.WebSettings;
import android.webkit.ValueCallback;
import android.net.Uri;
import android.content.Intent;
import android.database.Cursor;
import android.provider.OpenableColumns;
import android.webkit.JavascriptInterface;
import android.widget.Toast;
import java.io.InputStream;
import java.io.ByteArrayOutputStream;
import android.util.Base64;

public class MainActivity extends Activity {
    private WebView web;
    private static final int PICK_APK = 42;
    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        web = new WebView(this);
        setContentView(web);
        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setAllowFileAccess(true);
        s.setAllowContentAccess(true);
        s.setJavaScriptCanOpenWindowsAutomatically(true);
        web.setWebViewClient(new WebViewClient());
        web.setWebChromeClient(new WebChromeClient());
        web.addJavascriptInterface(new Object() {
            @JavascriptInterface public void chooseApk() {
                runOnUiThread(() -> {
                    Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT);
                    i.addCategory(Intent.CATEGORY_OPENABLE);
                    i.setType("application/vnd.android.package-archive");
                    startActivityForResult(i, PICK_APK);
                });
            }
        }, "AndroidBridge");
        web.loadUrl("file:///android_asset/index.html");
    }
    @Override protected void onActivityResult(int req, int res, Intent data) {
        super.onActivityResult(req,res,data);
        if(req == PICK_APK && res == RESULT_OK && data != null) {
            Uri uri=data.getData();
            try {
                InputStream in=getContentResolver().openInputStream(uri);
                ByteArrayOutputStream out=new ByteArrayOutputStream();
                byte[] buf=new byte[8192]; int n;
                while((n=in.read(buf))>0) out.write(buf,0,n);
                in.close();
                String b64=Base64.encodeToString(out.toByteArray(), Base64.NO_WRAP);
                String name="APK";
                Cursor c=getContentResolver().query(uri,null,null,null,null);
                if(c!=null){ int ix=c.getColumnIndex(OpenableColumns.DISPLAY_NAME); if(c.moveToFirst()&&ix>=0) name=c.getString(ix); c.close(); }
                String js="window.receiveApkFromAndroid && window.receiveApkFromAndroid("+JSONObjectQuote(name)+","+JSONObjectQuote(b64)+")";
                web.evaluateJavascript(js,null);
            } catch(Exception e) { Toast.makeText(this,"Could not read selected APK",Toast.LENGTH_LONG).show(); }
        }
    }
    private String JSONObjectQuote(String s) {
        return "\"" + s.replace("\\","\\\\").replace("\"","\\\"").replace("\n","\\n") + "\"";
    }
    @Override public void onBackPressed() {
        if(web != null && web.canGoBack()) web.goBack(); else super.onBackPressed();
    }
}
